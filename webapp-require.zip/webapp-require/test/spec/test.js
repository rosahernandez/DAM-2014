/* global describe, it */

(function () {
    'use strict';

//  tests.js

    require.config({
        baseUrl: '../app/scripts',
        nodeRequire:    require
    });

        describe('Give it some context', function () {
            var FizzBuzz;
            var Fizz;
            var Buzz;

            beforeEach(function(done){
            require(['FizzBuzz','Fizz','Buzz'], function(fb,f,b){
                FizzBuzz =   fb;
                Fizz =   f;
                Buzz =   b;
                done();
            });
        });


        describe('maybe a bit more context here', function () {
            it('should run here few assertions', function () {

                assert.equal(1, FizzBuzz.testNumber(1));
                assert.equal('FIZZ', FizzBuzz.testNumber(3));
                assert.equal('BUZZ', FizzBuzz.testNumber(5));
                assert.equal('FIZZBUZZ', FizzBuzz.testNumber(15));
                //assert.equal(false, FizzBuzz.testNumber());
                assert.equal(true, Fizz.isFizz(3));
                assert.equal(false, Fizz.isFizz(7));
                assert.equal(false, Fizz.isFizz());
                assert.equal(false, Buzz.isBuzz());
                assert.equal(true, Buzz.isBuzz(5));
                assert.equal(false, Buzz.isBuzz(7));
                expect( FizzBuzz.testNumber()).to.be.undefined;
            });
        });
    });
})();
